package com.example.quiztest;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.stream.Stream;

public class FileManager {
    private static ArrayList<String> readLineByLineJava8(String filePath)
    {
        ArrayList<String> list = new ArrayList<>();
        StringBuilder contentBuilder = new StringBuilder();

        try (Stream<String> stream = Files.lines( Paths.get(filePath), StandardCharsets.UTF_8))
        {
            stream.forEach(s -> list.add(s));
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        return list;
    }

    public void generateQuizesFromStringList() {

    }
}

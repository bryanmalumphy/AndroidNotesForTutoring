package com.example.quiztest;

import android.media.Image;

public class QuizCard {
    private String title;

    QuizCard(String title, Image image, String description) {
        this.title = title;
    }
}

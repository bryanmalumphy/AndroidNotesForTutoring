package com.example.quiztest;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class QuizAdapter extends RecyclerView.Adapter<QuizAdapter.QuizViewHolder> {
    private ArrayList<String> quizTitles;

    public static class QuizViewHolder extends RecyclerView.ViewHolder {
        public TextView titleTextView;
        public QuizViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.quizTitle);
        }
    }

    public QuizAdapter(ArrayList<String> quizTitles) {
        this.quizTitles = quizTitles;
    }

    @NonNull
    @Override
    public QuizViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.quiz_card, parent, false);
        QuizViewHolder viewHolder = new QuizViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(QuizViewHolder holder, int position) {
        String title = quizTitles.get(position);
        holder.titleTextView.setText(title);
    }

    @Override
    public int getItemCount() {
        return quizTitles.size();
    }
}
